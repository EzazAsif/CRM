<h1>Welcome to <?php echo $_settings->info('name') ?></h1>

<div class="shadow-lg p-3 mb-5 bg-white rounded" >
<?php include './chart/chart.php' ?>
</div>
